#employees = __import__("10-4")
import employees
import pickle

def menu():
    print("Employee Management System")
    print("--------------------------")
    print("Press 1 to Look Up Employee")
    print("Press 2 to Add New Employee")
    print("Press 3 to Update Employee")
    print("Press 4 to Delete Employee")
    print("Press Q to Save and Quit")

def lookup(employee_dict):
    while True:
        try:
            id = int(input("Enter the new employee ID: "))
            break
        except:
            print("Invalid ID!")

    if id in employee_dict.keys():
        print("")
        print(employee_dict[id])
        print("")
    else:
        print("Employee ID Not Found!")

def add(employee_dict):
    while True:
        try:
            id = int(input("Enter the new employee ID: "))
            if id > 0 and id < 1000:
                break
            else:
                print("ID's must be between 0 and 1000")
        except:
            print("Invalid ID!")

    name = input("Enter the new employee name: ")
    dept = input("Enter the new employee department: ")
    title = input("Enter the new employee job title: ")

    employee_dict[id] = employees.Employee(name, id, dept, title)


def update(employee_dict):
    while True:
        try:
            id = int(input("Enter the new employee ID: "))
            break
        except:
            print("Invalid ID!")

    if id in employee_dict.keys():
        name = input("Enter the updated employee name: ")
        dept = input("Enter the updated employee department: ")
        title = input("Enter the updated employee job title: ")

        employee_dict[id].set_name(name)
        employee_dict[id].set_department(dept)
        employee_dict[id].set_job_title(title)


def delete(employee_dict):
    while True:
        try:
            id = int(input("Enter the employee ID to delete: "))
            break
        except:
            print("Invalid ID!")

    if id in employee_dict.keys():
        del employee_dict[id]
    else:
        print("Employee ID Not Found!")

def main():
    employee_dict = {}
    try:
        fp = open("employees.dat", "rb")
        employee_dict = pickle.load(fp)
        fp.close()
    except:
        print("File Not Found: Starting with Empty Dataset")

    while True:
        menu()
        choice = input("Enter Choice Here: ")
        if choice == "1":
            lookup(employee_dict)
        elif choice == "2":
            add(employee_dict)
        elif choice == "3":
            update(employee_dict)
        elif choice == "4":
            delete(employee_dict)
        elif choice == "Q":
            break

    try:
        fp = open("employees.dat", "wb")
        pickle.dump(employee_dict, fp)
        fp.close()
    except Exception as e:
        print("Unkown Error Found: ")
        print(e)



if __name__ == "__main__":
    main()
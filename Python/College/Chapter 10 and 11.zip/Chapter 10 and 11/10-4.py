

class Employee:
    __name = ""
    __id = -1
    __department = ""
    __job_title = ""

    def __init__(self, name, id, department, job_title):
        self.set_name(name)
        self.__set_id(id)
        self.set_department(department)
        self.set_job_title(job_title)

    def __str__(self):
        return "{}: {} - {}, {}".format(
            self.__id,
            self.__name,
            self.__department,
            self.__job_title
        )

    def set_name(self, name):
        if name.replace(" ", "").isalpha():
            self.__name = name

    def __set_id(self, id):
        if 0 < id < 1000:
            self.__id = id

    def set_department(self, department):
        if department.replace(" ", "").isalpha():
            self.__department = department

    def set_job_title(self, job_title):
        if job_title.replace(" ", "").isalpha():
            self.__job_title = job_title

    def get_name(self):
        return self.__name

    def get_id(self):
        return self.__id

    def get_department(self):
        return self.__department

    def get_job_title(self):
        return self.__job_title


def main():
    e1 = Employee("John Shouldre", 25, "IT", "Toilet Cleaner")
    e2 = Employee("Matt Hunt", 23, "Mantinence", "Janitor")
    e3 = Employee("Charles Xaiver", 1, "Psychology", "Department Chair")
    employees = [e1, e2, e3]
    for item in employees:
        print(item)
    print(employees)

if __name__ == "__main__":
    main()
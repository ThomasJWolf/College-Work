﻿namespace Wolf_6._5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OilAndLubegpb = new System.Windows.Forms.GroupBox();
            this.Lubejobcbx = new System.Windows.Forms.CheckBox();
            this.OilChangecbx = new System.Windows.Forms.CheckBox();
            this.Fushesgbx = new System.Windows.Forms.GroupBox();
            this.TransmissionFlushcbx = new System.Windows.Forms.CheckBox();
            this.RadiatorFlushcbx = new System.Windows.Forms.CheckBox();
            this.Miscgpb = new System.Windows.Forms.GroupBox();
            this.TireRotationcbx = new System.Windows.Forms.CheckBox();
            this.ReplaceMufflercbx = new System.Windows.Forms.CheckBox();
            this.Inspectioncbx = new System.Windows.Forms.CheckBox();
            this.PartsAndLaborgbx = new System.Windows.Forms.GroupBox();
            this.Labortxb = new System.Windows.Forms.TextBox();
            this.Partstxb = new System.Windows.Forms.TextBox();
            this.Laborlbl = new System.Windows.Forms.Label();
            this.Partslbl1 = new System.Windows.Forms.Label();
            this.Summarygbx = new System.Windows.Forms.GroupBox();
            this.TotalFeesOutlbl = new System.Windows.Forms.Label();
            this.TaxOutlbl = new System.Windows.Forms.Label();
            this.PartsOutlbl = new System.Windows.Forms.Label();
            this.ServiceLaborOutlbl = new System.Windows.Forms.Label();
            this.TotalFeeslbl = new System.Windows.Forms.Label();
            this.Taxlbl = new System.Windows.Forms.Label();
            this.Partslbl2 = new System.Windows.Forms.Label();
            this.ServiceLaborlbl = new System.Windows.Forms.Label();
            this.Calculatebtn = new System.Windows.Forms.Button();
            this.Clearbtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.OilAndLubegpb.SuspendLayout();
            this.Fushesgbx.SuspendLayout();
            this.Miscgpb.SuspendLayout();
            this.PartsAndLaborgbx.SuspendLayout();
            this.Summarygbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // OilAndLubegpb
            // 
            this.OilAndLubegpb.Controls.Add(this.Lubejobcbx);
            this.OilAndLubegpb.Controls.Add(this.OilChangecbx);
            this.OilAndLubegpb.Location = new System.Drawing.Point(12, 12);
            this.OilAndLubegpb.Name = "OilAndLubegpb";
            this.OilAndLubegpb.Size = new System.Drawing.Size(157, 77);
            this.OilAndLubegpb.TabIndex = 0;
            this.OilAndLubegpb.TabStop = false;
            this.OilAndLubegpb.Text = "Oil and Lube";
            // 
            // Lubejobcbx
            // 
            this.Lubejobcbx.AutoSize = true;
            this.Lubejobcbx.Location = new System.Drawing.Point(6, 42);
            this.Lubejobcbx.Name = "Lubejobcbx";
            this.Lubejobcbx.Size = new System.Drawing.Size(106, 17);
            this.Lubejobcbx.TabIndex = 1;
            this.Lubejobcbx.Text = "Lubejob ($18.00)";
            this.Lubejobcbx.UseVisualStyleBackColor = true;
            // 
            // OilChangecbx
            // 
            this.OilChangecbx.AutoSize = true;
            this.OilChangecbx.Location = new System.Drawing.Point(6, 19);
            this.OilChangecbx.Name = "OilChangecbx";
            this.OilChangecbx.Size = new System.Drawing.Size(120, 17);
            this.OilChangecbx.TabIndex = 0;
            this.OilChangecbx.Text = "Oil Change ($26.00)";
            this.OilChangecbx.UseVisualStyleBackColor = true;
            // 
            // Fushesgbx
            // 
            this.Fushesgbx.Controls.Add(this.TransmissionFlushcbx);
            this.Fushesgbx.Controls.Add(this.RadiatorFlushcbx);
            this.Fushesgbx.Location = new System.Drawing.Point(173, 12);
            this.Fushesgbx.Name = "Fushesgbx";
            this.Fushesgbx.Size = new System.Drawing.Size(167, 77);
            this.Fushesgbx.TabIndex = 1;
            this.Fushesgbx.TabStop = false;
            this.Fushesgbx.Text = "Fushes";
            // 
            // TransmissionFlushcbx
            // 
            this.TransmissionFlushcbx.AutoSize = true;
            this.TransmissionFlushcbx.Location = new System.Drawing.Point(6, 42);
            this.TransmissionFlushcbx.Name = "TransmissionFlushcbx";
            this.TransmissionFlushcbx.Size = new System.Drawing.Size(157, 17);
            this.TransmissionFlushcbx.TabIndex = 3;
            this.TransmissionFlushcbx.Text = "Transmission Flush ($80.00)";
            this.TransmissionFlushcbx.UseVisualStyleBackColor = true;
            // 
            // RadiatorFlushcbx
            // 
            this.RadiatorFlushcbx.AutoSize = true;
            this.RadiatorFlushcbx.Location = new System.Drawing.Point(6, 19);
            this.RadiatorFlushcbx.Name = "RadiatorFlushcbx";
            this.RadiatorFlushcbx.Size = new System.Drawing.Size(136, 17);
            this.RadiatorFlushcbx.TabIndex = 2;
            this.RadiatorFlushcbx.Text = "Radiator Flush ($30.00)";
            this.RadiatorFlushcbx.UseVisualStyleBackColor = true;
            // 
            // Miscgpb
            // 
            this.Miscgpb.Controls.Add(this.TireRotationcbx);
            this.Miscgpb.Controls.Add(this.ReplaceMufflercbx);
            this.Miscgpb.Controls.Add(this.Inspectioncbx);
            this.Miscgpb.Location = new System.Drawing.Point(12, 99);
            this.Miscgpb.Name = "Miscgpb";
            this.Miscgpb.Size = new System.Drawing.Size(154, 106);
            this.Miscgpb.TabIndex = 2;
            this.Miscgpb.TabStop = false;
            this.Miscgpb.Text = "Misc";
            // 
            // TireRotationcbx
            // 
            this.TireRotationcbx.AutoSize = true;
            this.TireRotationcbx.Location = new System.Drawing.Point(6, 68);
            this.TireRotationcbx.Name = "TireRotationcbx";
            this.TireRotationcbx.Size = new System.Drawing.Size(129, 17);
            this.TireRotationcbx.TabIndex = 10;
            this.TireRotationcbx.Text = "Tire Rotation ($20.00)";
            this.TireRotationcbx.UseVisualStyleBackColor = true;
            // 
            // ReplaceMufflercbx
            // 
            this.ReplaceMufflercbx.AutoSize = true;
            this.ReplaceMufflercbx.Location = new System.Drawing.Point(6, 44);
            this.ReplaceMufflercbx.Name = "ReplaceMufflercbx";
            this.ReplaceMufflercbx.Size = new System.Drawing.Size(149, 17);
            this.ReplaceMufflercbx.TabIndex = 9;
            this.ReplaceMufflercbx.Text = "Replace Muffler ($100.00)";
            this.ReplaceMufflercbx.UseVisualStyleBackColor = true;
            // 
            // Inspectioncbx
            // 
            this.Inspectioncbx.AutoSize = true;
            this.Inspectioncbx.Location = new System.Drawing.Point(6, 19);
            this.Inspectioncbx.Name = "Inspectioncbx";
            this.Inspectioncbx.Size = new System.Drawing.Size(117, 17);
            this.Inspectioncbx.TabIndex = 8;
            this.Inspectioncbx.Text = "Inspection ($15.00)";
            this.Inspectioncbx.UseVisualStyleBackColor = true;
            // 
            // PartsAndLaborgbx
            // 
            this.PartsAndLaborgbx.Controls.Add(this.Labortxb);
            this.PartsAndLaborgbx.Controls.Add(this.Partstxb);
            this.PartsAndLaborgbx.Controls.Add(this.Laborlbl);
            this.PartsAndLaborgbx.Controls.Add(this.Partslbl1);
            this.PartsAndLaborgbx.Location = new System.Drawing.Point(173, 99);
            this.PartsAndLaborgbx.Name = "PartsAndLaborgbx";
            this.PartsAndLaborgbx.Size = new System.Drawing.Size(167, 107);
            this.PartsAndLaborgbx.TabIndex = 3;
            this.PartsAndLaborgbx.TabStop = false;
            this.PartsAndLaborgbx.Text = "Parts and Labor";
            // 
            // Labortxb
            // 
            this.Labortxb.Location = new System.Drawing.Point(78, 59);
            this.Labortxb.Name = "Labortxb";
            this.Labortxb.Size = new System.Drawing.Size(49, 20);
            this.Labortxb.TabIndex = 3;
            // 
            // Partstxb
            // 
            this.Partstxb.Location = new System.Drawing.Point(78, 26);
            this.Partstxb.Name = "Partstxb";
            this.Partstxb.Size = new System.Drawing.Size(49, 20);
            this.Partstxb.TabIndex = 2;
            // 
            // Laborlbl
            // 
            this.Laborlbl.AutoSize = true;
            this.Laborlbl.Location = new System.Drawing.Point(21, 62);
            this.Laborlbl.Name = "Laborlbl";
            this.Laborlbl.Size = new System.Drawing.Size(49, 13);
            this.Laborlbl.TabIndex = 1;
            this.Laborlbl.Text = "Labor ($)";
            // 
            // Partslbl1
            // 
            this.Partslbl1.AutoSize = true;
            this.Partslbl1.Location = new System.Drawing.Point(42, 27);
            this.Partslbl1.Name = "Partslbl1";
            this.Partslbl1.Size = new System.Drawing.Size(31, 13);
            this.Partslbl1.TabIndex = 0;
            this.Partslbl1.Text = "Parts";
            // 
            // Summarygbx
            // 
            this.Summarygbx.Controls.Add(this.TotalFeesOutlbl);
            this.Summarygbx.Controls.Add(this.TaxOutlbl);
            this.Summarygbx.Controls.Add(this.PartsOutlbl);
            this.Summarygbx.Controls.Add(this.ServiceLaborOutlbl);
            this.Summarygbx.Controls.Add(this.TotalFeeslbl);
            this.Summarygbx.Controls.Add(this.Taxlbl);
            this.Summarygbx.Controls.Add(this.Partslbl2);
            this.Summarygbx.Controls.Add(this.ServiceLaborlbl);
            this.Summarygbx.Location = new System.Drawing.Point(12, 214);
            this.Summarygbx.Name = "Summarygbx";
            this.Summarygbx.Size = new System.Drawing.Size(329, 146);
            this.Summarygbx.TabIndex = 4;
            this.Summarygbx.TabStop = false;
            this.Summarygbx.Text = "Summary";
            // 
            // TotalFeesOutlbl
            // 
            this.TotalFeesOutlbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TotalFeesOutlbl.Location = new System.Drawing.Point(104, 106);
            this.TotalFeesOutlbl.Name = "TotalFeesOutlbl";
            this.TotalFeesOutlbl.Size = new System.Drawing.Size(100, 23);
            this.TotalFeesOutlbl.TabIndex = 5;
            this.TotalFeesOutlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TaxOutlbl
            // 
            this.TaxOutlbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TaxOutlbl.Location = new System.Drawing.Point(104, 76);
            this.TaxOutlbl.Name = "TaxOutlbl";
            this.TaxOutlbl.Size = new System.Drawing.Size(100, 23);
            this.TaxOutlbl.TabIndex = 5;
            this.TaxOutlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PartsOutlbl
            // 
            this.PartsOutlbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PartsOutlbl.Location = new System.Drawing.Point(104, 46);
            this.PartsOutlbl.Name = "PartsOutlbl";
            this.PartsOutlbl.Size = new System.Drawing.Size(100, 23);
            this.PartsOutlbl.TabIndex = 5;
            this.PartsOutlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ServiceLaborOutlbl
            // 
            this.ServiceLaborOutlbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ServiceLaborOutlbl.Location = new System.Drawing.Point(104, 16);
            this.ServiceLaborOutlbl.Name = "ServiceLaborOutlbl";
            this.ServiceLaborOutlbl.Size = new System.Drawing.Size(100, 23);
            this.ServiceLaborOutlbl.TabIndex = 4;
            this.ServiceLaborOutlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TotalFeeslbl
            // 
            this.TotalFeeslbl.Location = new System.Drawing.Point(21, 114);
            this.TotalFeeslbl.Name = "TotalFeeslbl";
            this.TotalFeeslbl.Size = new System.Drawing.Size(77, 13);
            this.TotalFeeslbl.TabIndex = 3;
            this.TotalFeeslbl.Text = "Total Fees";
            this.TotalFeeslbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Taxlbl
            // 
            this.Taxlbl.Location = new System.Drawing.Point(21, 84);
            this.Taxlbl.Name = "Taxlbl";
            this.Taxlbl.Size = new System.Drawing.Size(77, 13);
            this.Taxlbl.TabIndex = 2;
            this.Taxlbl.Text = "Tax (on parts)";
            this.Taxlbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Partslbl2
            // 
            this.Partslbl2.Location = new System.Drawing.Point(21, 52);
            this.Partslbl2.Name = "Partslbl2";
            this.Partslbl2.Size = new System.Drawing.Size(77, 13);
            this.Partslbl2.TabIndex = 1;
            this.Partslbl2.Text = "Parts";
            this.Partslbl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ServiceLaborlbl
            // 
            this.ServiceLaborlbl.Location = new System.Drawing.Point(3, 23);
            this.ServiceLaborlbl.Name = "ServiceLaborlbl";
            this.ServiceLaborlbl.Size = new System.Drawing.Size(95, 13);
            this.ServiceLaborlbl.TabIndex = 0;
            this.ServiceLaborlbl.Text = "Service and Labor";
            this.ServiceLaborlbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Calculatebtn
            // 
            this.Calculatebtn.Location = new System.Drawing.Point(59, 381);
            this.Calculatebtn.Name = "Calculatebtn";
            this.Calculatebtn.Size = new System.Drawing.Size(75, 23);
            this.Calculatebtn.TabIndex = 5;
            this.Calculatebtn.Text = "Calculate";
            this.Calculatebtn.UseVisualStyleBackColor = true;
            this.Calculatebtn.Click += new System.EventHandler(this.Calculatebtn_Click);
            // 
            // Clearbtn
            // 
            this.Clearbtn.Location = new System.Drawing.Point(140, 381);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(75, 23);
            this.Clearbtn.TabIndex = 6;
            this.Clearbtn.Text = "Clear";
            this.Clearbtn.UseVisualStyleBackColor = true;
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.Location = new System.Drawing.Point(219, 381);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(75, 23);
            this.Exitbtn.TabIndex = 7;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 421);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.Clearbtn);
            this.Controls.Add(this.Calculatebtn);
            this.Controls.Add(this.Summarygbx);
            this.Controls.Add(this.PartsAndLaborgbx);
            this.Controls.Add(this.Miscgpb);
            this.Controls.Add(this.Fushesgbx);
            this.Controls.Add(this.OilAndLubegpb);
            this.Name = "Automotive";
            this.Text = "Automotive";
            this.OilAndLubegpb.ResumeLayout(false);
            this.OilAndLubegpb.PerformLayout();
            this.Fushesgbx.ResumeLayout(false);
            this.Fushesgbx.PerformLayout();
            this.Miscgpb.ResumeLayout(false);
            this.Miscgpb.PerformLayout();
            this.PartsAndLaborgbx.ResumeLayout(false);
            this.PartsAndLaborgbx.PerformLayout();
            this.Summarygbx.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox OilAndLubegpb;
        private System.Windows.Forms.GroupBox Fushesgbx;
        private System.Windows.Forms.GroupBox Miscgpb;
        private System.Windows.Forms.GroupBox PartsAndLaborgbx;
        private System.Windows.Forms.GroupBox Summarygbx;
        private System.Windows.Forms.TextBox Labortxb;
        private System.Windows.Forms.TextBox Partstxb;
        private System.Windows.Forms.Label Laborlbl;
        private System.Windows.Forms.Label Partslbl1;
        private System.Windows.Forms.Label TotalFeeslbl;
        private System.Windows.Forms.Label Taxlbl;
        private System.Windows.Forms.Label Partslbl2;
        private System.Windows.Forms.Label ServiceLaborlbl;
        private System.Windows.Forms.Label TotalFeesOutlbl;
        private System.Windows.Forms.Label TaxOutlbl;
        private System.Windows.Forms.Label PartsOutlbl;
        private System.Windows.Forms.Label ServiceLaborOutlbl;
        private System.Windows.Forms.Button Calculatebtn;
        private System.Windows.Forms.Button Clearbtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.CheckBox Lubejobcbx;
        private System.Windows.Forms.CheckBox OilChangecbx;
        private System.Windows.Forms.CheckBox TransmissionFlushcbx;
        private System.Windows.Forms.CheckBox RadiatorFlushcbx;
        private System.Windows.Forms.CheckBox TireRotationcbx;
        private System.Windows.Forms.CheckBox ReplaceMufflercbx;
        private System.Windows.Forms.CheckBox Inspectioncbx;
    }
}


﻿namespace Wolf_3._14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TicketsSoldgb = new System.Windows.Forms.GroupBox();
            this.Infolbl = new System.Windows.Forms.Label();
            this.ClassBInputlbl = new System.Windows.Forms.Label();
            this.ClassCInputlbl = new System.Windows.Forms.Label();
            this.ClassCInputtxb = new System.Windows.Forms.TextBox();
            this.ClassAInputtxb = new System.Windows.Forms.TextBox();
            this.ClassBInputtxb = new System.Windows.Forms.TextBox();
            this.ClassAInputlbl = new System.Windows.Forms.Label();
            this.RevenueGeneratedgb = new System.Windows.Forms.GroupBox();
            this.TotalResultlbl = new System.Windows.Forms.Label();
            this.Totallbl = new System.Windows.Forms.Label();
            this.ClassCResultlbl = new System.Windows.Forms.Label();
            this.ClassBResultlbl = new System.Windows.Forms.Label();
            this.ClassAResultlbl = new System.Windows.Forms.Label();
            this.ClassBOutputlbl = new System.Windows.Forms.Label();
            this.ClassCOutputlbl = new System.Windows.Forms.Label();
            this.ClassAOutputlbl = new System.Windows.Forms.Label();
            this.Calculatebtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.Clearbtn = new System.Windows.Forms.Button();
            this.TicketsSoldgb.SuspendLayout();
            this.RevenueGeneratedgb.SuspendLayout();
            this.SuspendLayout();
            // 
            // TicketsSoldgb
            // 
            this.TicketsSoldgb.Controls.Add(this.Infolbl);
            this.TicketsSoldgb.Controls.Add(this.ClassBInputlbl);
            this.TicketsSoldgb.Controls.Add(this.ClassCInputlbl);
            this.TicketsSoldgb.Controls.Add(this.ClassCInputtxb);
            this.TicketsSoldgb.Controls.Add(this.ClassAInputtxb);
            this.TicketsSoldgb.Controls.Add(this.ClassBInputtxb);
            this.TicketsSoldgb.Controls.Add(this.ClassAInputlbl);
            this.TicketsSoldgb.Location = new System.Drawing.Point(12, 12);
            this.TicketsSoldgb.Name = "TicketsSoldgb";
            this.TicketsSoldgb.Size = new System.Drawing.Size(232, 196);
            this.TicketsSoldgb.TabIndex = 1;
            this.TicketsSoldgb.TabStop = false;
            this.TicketsSoldgb.Text = "Tickets Sold";
            // 
            // Infolbl
            // 
            this.Infolbl.AutoSize = true;
            this.Infolbl.Location = new System.Drawing.Point(25, 27);
            this.Infolbl.Name = "Infolbl";
            this.Infolbl.Size = new System.Drawing.Size(156, 26);
            this.Infolbl.TabIndex = 18;
            this.Infolbl.Text = "Enter the number of tickets sold\r\nfor each class of seats.";
            // 
            // ClassBInputlbl
            // 
            this.ClassBInputlbl.AutoSize = true;
            this.ClassBInputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassBInputlbl.Location = new System.Drawing.Point(39, 115);
            this.ClassBInputlbl.Name = "ClassBInputlbl";
            this.ClassBInputlbl.Size = new System.Drawing.Size(45, 13);
            this.ClassBInputlbl.TabIndex = 17;
            this.ClassBInputlbl.Text = "Class B:";
            this.ClassBInputlbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ClassCInputlbl
            // 
            this.ClassCInputlbl.AutoSize = true;
            this.ClassCInputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassCInputlbl.Location = new System.Drawing.Point(39, 147);
            this.ClassCInputlbl.Name = "ClassCInputlbl";
            this.ClassCInputlbl.Size = new System.Drawing.Size(45, 13);
            this.ClassCInputlbl.TabIndex = 16;
            this.ClassCInputlbl.Text = "Class C:";
            this.ClassCInputlbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ClassCInputtxb
            // 
            this.ClassCInputtxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassCInputtxb.Location = new System.Drawing.Point(90, 144);
            this.ClassCInputtxb.Name = "ClassCInputtxb";
            this.ClassCInputtxb.Size = new System.Drawing.Size(100, 20);
            this.ClassCInputtxb.TabIndex = 15;
            // 
            // ClassAInputtxb
            // 
            this.ClassAInputtxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassAInputtxb.Location = new System.Drawing.Point(90, 78);
            this.ClassAInputtxb.Name = "ClassAInputtxb";
            this.ClassAInputtxb.Size = new System.Drawing.Size(100, 20);
            this.ClassAInputtxb.TabIndex = 10;
            // 
            // ClassBInputtxb
            // 
            this.ClassBInputtxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassBInputtxb.Location = new System.Drawing.Point(90, 108);
            this.ClassBInputtxb.Name = "ClassBInputtxb";
            this.ClassBInputtxb.Size = new System.Drawing.Size(100, 20);
            this.ClassBInputtxb.TabIndex = 14;
            // 
            // ClassAInputlbl
            // 
            this.ClassAInputlbl.AutoSize = true;
            this.ClassAInputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassAInputlbl.Location = new System.Drawing.Point(39, 81);
            this.ClassAInputlbl.Name = "ClassAInputlbl";
            this.ClassAInputlbl.Size = new System.Drawing.Size(45, 13);
            this.ClassAInputlbl.TabIndex = 11;
            this.ClassAInputlbl.Text = "Class A:";
            this.ClassAInputlbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // RevenueGeneratedgb
            // 
            this.RevenueGeneratedgb.Controls.Add(this.TotalResultlbl);
            this.RevenueGeneratedgb.Controls.Add(this.Totallbl);
            this.RevenueGeneratedgb.Controls.Add(this.ClassCResultlbl);
            this.RevenueGeneratedgb.Controls.Add(this.ClassBResultlbl);
            this.RevenueGeneratedgb.Controls.Add(this.ClassAResultlbl);
            this.RevenueGeneratedgb.Controls.Add(this.ClassBOutputlbl);
            this.RevenueGeneratedgb.Controls.Add(this.ClassCOutputlbl);
            this.RevenueGeneratedgb.Controls.Add(this.ClassAOutputlbl);
            this.RevenueGeneratedgb.Location = new System.Drawing.Point(272, 12);
            this.RevenueGeneratedgb.Name = "RevenueGeneratedgb";
            this.RevenueGeneratedgb.Size = new System.Drawing.Size(241, 196);
            this.RevenueGeneratedgb.TabIndex = 19;
            this.RevenueGeneratedgb.TabStop = false;
            this.RevenueGeneratedgb.Text = "Revenue Generated";
            // 
            // TotalResultlbl
            // 
            this.TotalResultlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalResultlbl.Location = new System.Drawing.Point(84, 141);
            this.TotalResultlbl.Name = "TotalResultlbl";
            this.TotalResultlbl.Size = new System.Drawing.Size(132, 32);
            this.TotalResultlbl.TabIndex = 22;
            this.TotalResultlbl.Text = "  \r\n\r\n";
            this.TotalResultlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Totallbl
            // 
            this.Totallbl.AutoSize = true;
            this.Totallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Totallbl.Location = new System.Drawing.Point(44, 151);
            this.Totallbl.Name = "Totallbl";
            this.Totallbl.Size = new System.Drawing.Size(34, 13);
            this.Totallbl.TabIndex = 21;
            this.Totallbl.Text = "Total:";
            this.Totallbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ClassCResultlbl
            // 
            this.ClassCResultlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ClassCResultlbl.Location = new System.Drawing.Point(84, 108);
            this.ClassCResultlbl.Name = "ClassCResultlbl";
            this.ClassCResultlbl.Size = new System.Drawing.Size(132, 32);
            this.ClassCResultlbl.TabIndex = 20;
            this.ClassCResultlbl.Text = "  \r\n\r\n";
            this.ClassCResultlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ClassBResultlbl
            // 
            this.ClassBResultlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ClassBResultlbl.Location = new System.Drawing.Point(84, 75);
            this.ClassBResultlbl.Name = "ClassBResultlbl";
            this.ClassBResultlbl.Size = new System.Drawing.Size(132, 32);
            this.ClassBResultlbl.TabIndex = 19;
            this.ClassBResultlbl.Text = "  \r\n\r\n";
            this.ClassBResultlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ClassAResultlbl
            // 
            this.ClassAResultlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ClassAResultlbl.Location = new System.Drawing.Point(84, 41);
            this.ClassAResultlbl.Name = "ClassAResultlbl";
            this.ClassAResultlbl.Size = new System.Drawing.Size(132, 32);
            this.ClassAResultlbl.TabIndex = 18;
            this.ClassAResultlbl.Text = "  \r\n\r\n";
            this.ClassAResultlbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ClassBOutputlbl
            // 
            this.ClassBOutputlbl.AutoSize = true;
            this.ClassBOutputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassBOutputlbl.Location = new System.Drawing.Point(33, 85);
            this.ClassBOutputlbl.Name = "ClassBOutputlbl";
            this.ClassBOutputlbl.Size = new System.Drawing.Size(45, 13);
            this.ClassBOutputlbl.TabIndex = 17;
            this.ClassBOutputlbl.Text = "Class B:";
            this.ClassBOutputlbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ClassCOutputlbl
            // 
            this.ClassCOutputlbl.AutoSize = true;
            this.ClassCOutputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassCOutputlbl.Location = new System.Drawing.Point(33, 118);
            this.ClassCOutputlbl.Name = "ClassCOutputlbl";
            this.ClassCOutputlbl.Size = new System.Drawing.Size(45, 13);
            this.ClassCOutputlbl.TabIndex = 16;
            this.ClassCOutputlbl.Text = "Class C:";
            this.ClassCOutputlbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ClassAOutputlbl
            // 
            this.ClassAOutputlbl.AutoSize = true;
            this.ClassAOutputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClassAOutputlbl.Location = new System.Drawing.Point(33, 51);
            this.ClassAOutputlbl.Name = "ClassAOutputlbl";
            this.ClassAOutputlbl.Size = new System.Drawing.Size(45, 13);
            this.ClassAOutputlbl.TabIndex = 11;
            this.ClassAOutputlbl.Text = "Class A:";
            this.ClassAOutputlbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Calculatebtn
            // 
            this.Calculatebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculatebtn.Location = new System.Drawing.Point(120, 228);
            this.Calculatebtn.Name = "Calculatebtn";
            this.Calculatebtn.Size = new System.Drawing.Size(83, 46);
            this.Calculatebtn.TabIndex = 22;
            this.Calculatebtn.Text = "Calculate\r\nRevenue\r\n";
            this.Calculatebtn.UseVisualStyleBackColor = true;
            this.Calculatebtn.Click += new System.EventHandler(this.Calculatebtn_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbtn.Location = new System.Drawing.Point(298, 229);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(83, 46);
            this.Exitbtn.TabIndex = 21;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // Clearbtn
            // 
            this.Clearbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbtn.Location = new System.Drawing.Point(209, 229);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(83, 45);
            this.Clearbtn.TabIndex = 20;
            this.Clearbtn.Text = "Clear";
            this.Clearbtn.UseVisualStyleBackColor = true;
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(531, 289);
            this.Controls.Add(this.Calculatebtn);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.Clearbtn);
            this.Controls.Add(this.RevenueGeneratedgb);
            this.Controls.Add(this.TicketsSoldgb);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TicketsSoldgb.ResumeLayout(false);
            this.TicketsSoldgb.PerformLayout();
            this.RevenueGeneratedgb.ResumeLayout(false);
            this.RevenueGeneratedgb.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox TicketsSoldgb;
        private System.Windows.Forms.TextBox ClassCInputtxb;
        private System.Windows.Forms.TextBox ClassAInputtxb;
        private System.Windows.Forms.TextBox ClassBInputtxb;
        private System.Windows.Forms.Label ClassAInputlbl;
        private System.Windows.Forms.Label ClassBInputlbl;
        private System.Windows.Forms.Label ClassCInputlbl;
        private System.Windows.Forms.Label Infolbl;
        private System.Windows.Forms.GroupBox RevenueGeneratedgb;
        private System.Windows.Forms.Label ClassBOutputlbl;
        private System.Windows.Forms.Label ClassCOutputlbl;
        private System.Windows.Forms.Label ClassAOutputlbl;
        private System.Windows.Forms.Label ClassAResultlbl;
        private System.Windows.Forms.Label TotalResultlbl;
        private System.Windows.Forms.Label Totallbl;
        private System.Windows.Forms.Label ClassCResultlbl;
        private System.Windows.Forms.Label ClassBResultlbl;
        private System.Windows.Forms.Button Calculatebtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Button Clearbtn;
    }
}


﻿namespace Wolf_4._9
{
    partial class Dollar_Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dimestxb = new System.Windows.Forms.TextBox();
            this.Nicklestxb = new System.Windows.Forms.TextBox();
            this.Dimeslbl = new System.Windows.Forms.Label();
            this.Nickleslbl = new System.Windows.Forms.Label();
            this.Pennieslbl = new System.Windows.Forms.Label();
            this.Penniestxb = new System.Windows.Forms.TextBox();
            this.Quarterstxb = new System.Windows.Forms.TextBox();
            this.Quarterslbl = new System.Windows.Forms.Label();
            this.Titlelbl = new System.Windows.Forms.Label();
            this.Enterpnl = new System.Windows.Forms.Panel();
            this.Calculatebtn = new System.Windows.Forms.Button();
            this.Discriptionlbl = new System.Windows.Forms.Label();
            this.Exitpnl = new System.Windows.Forms.Panel();
            this.Winnerlbl = new System.Windows.Forms.Label();
            this.Resultlbl = new System.Windows.Forms.Label();
            this.Rlbl = new System.Windows.Forms.Label();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.Resetbtn = new System.Windows.Forms.Button();
            this.Enterpnl.SuspendLayout();
            this.Exitpnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // Dimestxb
            // 
            this.Dimestxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dimestxb.Location = new System.Drawing.Point(130, 99);
            this.Dimestxb.Name = "Dimestxb";
            this.Dimestxb.Size = new System.Drawing.Size(100, 31);
            this.Dimestxb.TabIndex = 15;
            // 
            // Nicklestxb
            // 
            this.Nicklestxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nicklestxb.Location = new System.Drawing.Point(130, 62);
            this.Nicklestxb.Name = "Nicklestxb";
            this.Nicklestxb.Size = new System.Drawing.Size(100, 31);
            this.Nicklestxb.TabIndex = 14;
            // 
            // Dimeslbl
            // 
            this.Dimeslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dimeslbl.Location = new System.Drawing.Point(23, 102);
            this.Dimeslbl.Name = "Dimeslbl";
            this.Dimeslbl.Size = new System.Drawing.Size(101, 25);
            this.Dimeslbl.TabIndex = 13;
            this.Dimeslbl.Text = "Dimes:";
            this.Dimeslbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Nickleslbl
            // 
            this.Nickleslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nickleslbl.Location = new System.Drawing.Point(23, 65);
            this.Nickleslbl.Name = "Nickleslbl";
            this.Nickleslbl.Size = new System.Drawing.Size(101, 25);
            this.Nickleslbl.TabIndex = 12;
            this.Nickleslbl.Text = "Nickels:";
            this.Nickleslbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Pennieslbl
            // 
            this.Pennieslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pennieslbl.Location = new System.Drawing.Point(18, 28);
            this.Pennieslbl.Name = "Pennieslbl";
            this.Pennieslbl.Size = new System.Drawing.Size(106, 25);
            this.Pennieslbl.TabIndex = 11;
            this.Pennieslbl.Text = "Pennies:";
            this.Pennieslbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Penniestxb
            // 
            this.Penniestxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Penniestxb.Location = new System.Drawing.Point(130, 25);
            this.Penniestxb.Name = "Penniestxb";
            this.Penniestxb.Size = new System.Drawing.Size(100, 31);
            this.Penniestxb.TabIndex = 10;
            // 
            // Quarterstxb
            // 
            this.Quarterstxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quarterstxb.Location = new System.Drawing.Point(130, 136);
            this.Quarterstxb.Name = "Quarterstxb";
            this.Quarterstxb.Size = new System.Drawing.Size(100, 31);
            this.Quarterstxb.TabIndex = 18;
            // 
            // Quarterslbl
            // 
            this.Quarterslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quarterslbl.Location = new System.Drawing.Point(23, 139);
            this.Quarterslbl.Name = "Quarterslbl";
            this.Quarterslbl.Size = new System.Drawing.Size(101, 25);
            this.Quarterslbl.TabIndex = 16;
            this.Quarterslbl.Text = "Quarters:";
            this.Quarterslbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Titlelbl
            // 
            this.Titlelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titlelbl.Location = new System.Drawing.Point(12, 9);
            this.Titlelbl.Name = "Titlelbl";
            this.Titlelbl.Size = new System.Drawing.Size(540, 55);
            this.Titlelbl.TabIndex = 19;
            this.Titlelbl.Text = "DOLLAR GAME";
            this.Titlelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Enterpnl
            // 
            this.Enterpnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Enterpnl.Controls.Add(this.Calculatebtn);
            this.Enterpnl.Controls.Add(this.Quarterstxb);
            this.Enterpnl.Controls.Add(this.Quarterslbl);
            this.Enterpnl.Controls.Add(this.Dimestxb);
            this.Enterpnl.Controls.Add(this.Dimeslbl);
            this.Enterpnl.Controls.Add(this.Nicklestxb);
            this.Enterpnl.Controls.Add(this.Nickleslbl);
            this.Enterpnl.Controls.Add(this.Penniestxb);
            this.Enterpnl.Controls.Add(this.Pennieslbl);
            this.Enterpnl.Location = new System.Drawing.Point(13, 113);
            this.Enterpnl.Name = "Enterpnl";
            this.Enterpnl.Size = new System.Drawing.Size(262, 243);
            this.Enterpnl.TabIndex = 20;
            // 
            // Calculatebtn
            // 
            this.Calculatebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculatebtn.Location = new System.Drawing.Point(60, 182);
            this.Calculatebtn.Name = "Calculatebtn";
            this.Calculatebtn.Size = new System.Drawing.Size(132, 46);
            this.Calculatebtn.TabIndex = 19;
            this.Calculatebtn.Text = "Calculate";
            this.Calculatebtn.UseVisualStyleBackColor = true;
            this.Calculatebtn.Click += new System.EventHandler(this.Calculatebtn_Click);
            // 
            // Discriptionlbl
            // 
            this.Discriptionlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Discriptionlbl.Location = new System.Drawing.Point(14, 51);
            this.Discriptionlbl.Name = "Discriptionlbl";
            this.Discriptionlbl.Size = new System.Drawing.Size(538, 59);
            this.Discriptionlbl.TabIndex = 21;
            this.Discriptionlbl.Text = "Enter the number of coins to make exactly one dollar!";
            this.Discriptionlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Exitpnl
            // 
            this.Exitpnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Exitpnl.Controls.Add(this.Winnerlbl);
            this.Exitpnl.Controls.Add(this.Resultlbl);
            this.Exitpnl.Controls.Add(this.Rlbl);
            this.Exitpnl.Location = new System.Drawing.Point(290, 113);
            this.Exitpnl.Name = "Exitpnl";
            this.Exitpnl.Size = new System.Drawing.Size(262, 181);
            this.Exitpnl.TabIndex = 21;
            // 
            // Winnerlbl
            // 
            this.Winnerlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Winnerlbl.Location = new System.Drawing.Point(0, 125);
            this.Winnerlbl.Name = "Winnerlbl";
            this.Winnerlbl.Size = new System.Drawing.Size(262, 54);
            this.Winnerlbl.TabIndex = 24;
            this.Winnerlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Resultlbl
            // 
            this.Resultlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resultlbl.Location = new System.Drawing.Point(0, 65);
            this.Resultlbl.Name = "Resultlbl";
            this.Resultlbl.Size = new System.Drawing.Size(262, 46);
            this.Resultlbl.TabIndex = 23;
            this.Resultlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Rlbl
            // 
            this.Rlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rlbl.Location = new System.Drawing.Point(-2, 9);
            this.Rlbl.Name = "Rlbl";
            this.Rlbl.Size = new System.Drawing.Size(262, 56);
            this.Rlbl.TabIndex = 22;
            this.Rlbl.Text = "Result";
            this.Rlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Exitbtn
            // 
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbtn.Location = new System.Drawing.Point(429, 308);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(123, 46);
            this.Exitbtn.TabIndex = 20;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // Resetbtn
            // 
            this.Resetbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resetbtn.Location = new System.Drawing.Point(290, 308);
            this.Resetbtn.Name = "Resetbtn";
            this.Resetbtn.Size = new System.Drawing.Size(124, 46);
            this.Resetbtn.TabIndex = 21;
            this.Resetbtn.Text = "Reset";
            this.Resetbtn.UseVisualStyleBackColor = true;
            this.Resetbtn.Click += new System.EventHandler(this.Resetbtn_Click);
            // 
            // Dollar_Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 369);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.Resetbtn);
            this.Controls.Add(this.Exitpnl);
            this.Controls.Add(this.Discriptionlbl);
            this.Controls.Add(this.Titlelbl);
            this.Controls.Add(this.Enterpnl);
            this.Name = "Dollar_Game";
            this.Text = "Dollar Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Enterpnl.ResumeLayout(false);
            this.Enterpnl.PerformLayout();
            this.Exitpnl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox Dimestxb;
        private System.Windows.Forms.TextBox Nicklestxb;
        private System.Windows.Forms.Label Dimeslbl;
        private System.Windows.Forms.Label Nickleslbl;
        private System.Windows.Forms.Label Pennieslbl;
        private System.Windows.Forms.TextBox Penniestxb;
        private System.Windows.Forms.TextBox Quarterstxb;
        private System.Windows.Forms.Label Quarterslbl;
        private System.Windows.Forms.Label Titlelbl;
        private System.Windows.Forms.Panel Enterpnl;
        private System.Windows.Forms.Label Discriptionlbl;
        private System.Windows.Forms.Button Calculatebtn;
        private System.Windows.Forms.Panel Exitpnl;
        private System.Windows.Forms.Label Rlbl;
        private System.Windows.Forms.Label Winnerlbl;
        private System.Windows.Forms.Label Resultlbl;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Button Resetbtn;
    }
}


﻿namespace Wolf_11._1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Namelbl = new System.Windows.Forms.Label();
            this.Numberlbl = new System.Windows.Forms.Label();
            this.ShiftNumlbl = new System.Windows.Forms.Label();
            this.Paylbl = new System.Windows.Forms.Label();
            this.Nametbx = new System.Windows.Forms.TextBox();
            this.Paytxb = new System.Windows.Forms.TextBox();
            this.Numbertxb = new System.Windows.Forms.TextBox();
            this.ShiftNumcbx = new System.Windows.Forms.ComboBox();
            this.Submitbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Namelbl
            // 
            this.Namelbl.AutoSize = true;
            this.Namelbl.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.Namelbl.Location = new System.Drawing.Point(25, 63);
            this.Namelbl.Name = "Namelbl";
            this.Namelbl.Size = new System.Drawing.Size(224, 24);
            this.Namelbl.TabIndex = 0;
            this.Namelbl.Text = "Enter Employee Name:";
            this.Namelbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Numberlbl
            // 
            this.Numberlbl.AutoSize = true;
            this.Numberlbl.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Numberlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.Numberlbl.Location = new System.Drawing.Point(8, 103);
            this.Numberlbl.Name = "Numberlbl";
            this.Numberlbl.Size = new System.Drawing.Size(241, 24);
            this.Numberlbl.TabIndex = 1;
            this.Numberlbl.Text = "Enter Employee Number:";
            this.Numberlbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ShiftNumlbl
            // 
            this.ShiftNumlbl.AutoSize = true;
            this.ShiftNumlbl.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShiftNumlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.ShiftNumlbl.Location = new System.Drawing.Point(58, 143);
            this.ShiftNumlbl.Name = "ShiftNumlbl";
            this.ShiftNumlbl.Size = new System.Drawing.Size(191, 24);
            this.ShiftNumlbl.TabIndex = 2;
            this.ShiftNumlbl.Text = "Enter Shift Number:";
            this.ShiftNumlbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Paylbl
            // 
            this.Paylbl.AutoSize = true;
            this.Paylbl.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Paylbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.Paylbl.Location = new System.Drawing.Point(24, 183);
            this.Paylbl.Name = "Paylbl";
            this.Paylbl.Size = new System.Drawing.Size(225, 24);
            this.Paylbl.TabIndex = 3;
            this.Paylbl.Text = "Enter Hourly Pay Rate:";
            this.Paylbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Nametbx
            // 
            this.Nametbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.Nametbx.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nametbx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.Nametbx.Location = new System.Drawing.Point(255, 60);
            this.Nametbx.Name = "Nametbx";
            this.Nametbx.Size = new System.Drawing.Size(237, 32);
            this.Nametbx.TabIndex = 4;
            // 
            // Paytxb
            // 
            this.Paytxb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.Paytxb.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Paytxb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.Paytxb.Location = new System.Drawing.Point(255, 180);
            this.Paytxb.Name = "Paytxb";
            this.Paytxb.Size = new System.Drawing.Size(237, 32);
            this.Paytxb.TabIndex = 5;
            // 
            // Numbertxb
            // 
            this.Numbertxb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.Numbertxb.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Numbertxb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.Numbertxb.Location = new System.Drawing.Point(255, 100);
            this.Numbertxb.Name = "Numbertxb";
            this.Numbertxb.Size = new System.Drawing.Size(237, 32);
            this.Numbertxb.TabIndex = 6;
            // 
            // ShiftNumcbx
            // 
            this.ShiftNumcbx.AllowDrop = true;
            this.ShiftNumcbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.ShiftNumcbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShiftNumcbx.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShiftNumcbx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.ShiftNumcbx.FormattingEnabled = true;
            this.ShiftNumcbx.Items.AddRange(new object[] {
            "1 (day)",
            "2 (night)"});
            this.ShiftNumcbx.Location = new System.Drawing.Point(255, 140);
            this.ShiftNumcbx.Name = "ShiftNumcbx";
            this.ShiftNumcbx.Size = new System.Drawing.Size(237, 32);
            this.ShiftNumcbx.TabIndex = 7;
            // 
            // Submitbtn
            // 
            this.Submitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submitbtn.Location = new System.Drawing.Point(194, 218);
            this.Submitbtn.Name = "Submitbtn";
            this.Submitbtn.Size = new System.Drawing.Size(99, 32);
            this.Submitbtn.TabIndex = 8;
            this.Submitbtn.Text = "Submit";
            this.Submitbtn.UseVisualStyleBackColor = true;
            this.Submitbtn.Click += new System.EventHandler(this.Submitbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(137)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(36, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 40);
            this.label1.TabIndex = 9;
            this.label1.Text = "Enter Employee Information";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.ClientSize = new System.Drawing.Size(503, 259);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Submitbtn);
            this.Controls.Add(this.ShiftNumcbx);
            this.Controls.Add(this.Numbertxb);
            this.Controls.Add(this.Paytxb);
            this.Controls.Add(this.Nametbx);
            this.Controls.Add(this.Paylbl);
            this.Controls.Add(this.ShiftNumlbl);
            this.Controls.Add(this.Numberlbl);
            this.Controls.Add(this.Namelbl);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Namelbl;
        private System.Windows.Forms.Label Numberlbl;
        private System.Windows.Forms.Label ShiftNumlbl;
        private System.Windows.Forms.Label Paylbl;
        private System.Windows.Forms.TextBox Nametbx;
        private System.Windows.Forms.TextBox Paytxb;
        private System.Windows.Forms.TextBox Numbertxb;
        private System.Windows.Forms.ComboBox ShiftNumcbx;
        private System.Windows.Forms.Button Submitbtn;
        private System.Windows.Forms.Label label1;
    }
}


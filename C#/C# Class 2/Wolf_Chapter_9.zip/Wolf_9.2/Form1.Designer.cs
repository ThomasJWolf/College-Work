﻿namespace Wolf_9._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.Colapnl = new System.Windows.Forms.Panel();
            this.ColaDrinksAmountlbl = new System.Windows.Forms.Label();
            this.ColaDrinksLeftlbl = new System.Windows.Forms.Label();
            this.ColaCostlbl = new System.Windows.Forms.Label();
            this.Colapbx = new System.Windows.Forms.PictureBox();
            this.RootBeerpnl = new System.Windows.Forms.Panel();
            this.RootBeerDrinksAmountlbl = new System.Windows.Forms.Label();
            this.RootBeerDrinksLeftlbl = new System.Windows.Forms.Label();
            this.RootBeerCostlbl = new System.Windows.Forms.Label();
            this.RootBeerpbx = new System.Windows.Forms.PictureBox();
            this.LemonLimepnl = new System.Windows.Forms.Panel();
            this.LemonLimeDrinksAmountlbl = new System.Windows.Forms.Label();
            this.LemonLimeLeftlbl = new System.Windows.Forms.Label();
            this.LemonLimeCostlbl = new System.Windows.Forms.Label();
            this.LemonLimepxb = new System.Windows.Forms.PictureBox();
            this.GrapeSodapnl = new System.Windows.Forms.Panel();
            this.GrapeSodaDrinksAmountlbl = new System.Windows.Forms.Label();
            this.GrapeSodaDrinksLeftlbl = new System.Windows.Forms.Label();
            this.GrapeSodaCostlbl = new System.Windows.Forms.Label();
            this.GrapeSodapxb = new System.Windows.Forms.PictureBox();
            this.CreamSodapnl = new System.Windows.Forms.Panel();
            this.CreamSodaDrinksAmountlbl = new System.Windows.Forms.Label();
            this.CreamSodaDrinksLeftlbl = new System.Windows.Forms.Label();
            this.CreamSodaCostlbl = new System.Windows.Forms.Label();
            this.CreamSodapxb = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.TotalSalesOutputlbl = new System.Windows.Forms.Label();
            this.TotalSaleslbl = new System.Windows.Forms.Label();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.Colapnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Colapbx)).BeginInit();
            this.RootBeerpnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RootBeerpbx)).BeginInit();
            this.LemonLimepnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LemonLimepxb)).BeginInit();
            this.GrapeSodapnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrapeSodapxb)).BeginInit();
            this.CreamSodapnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreamSodapxb)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select a Drink";
            // 
            // Colapnl
            // 
            this.Colapnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Colapnl.Controls.Add(this.ColaDrinksAmountlbl);
            this.Colapnl.Controls.Add(this.ColaDrinksLeftlbl);
            this.Colapnl.Controls.Add(this.ColaCostlbl);
            this.Colapnl.Controls.Add(this.Colapbx);
            this.Colapnl.Cursor = System.Windows.Forms.Cursors.No;
            this.Colapnl.Location = new System.Drawing.Point(12, 49);
            this.Colapnl.Name = "Colapnl";
            this.Colapnl.Size = new System.Drawing.Size(176, 89);
            this.Colapnl.TabIndex = 1;
            // 
            // ColaDrinksAmountlbl
            // 
            this.ColaDrinksAmountlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ColaDrinksAmountlbl.Location = new System.Drawing.Point(98, 46);
            this.ColaDrinksAmountlbl.Name = "ColaDrinksAmountlbl";
            this.ColaDrinksAmountlbl.Size = new System.Drawing.Size(68, 29);
            this.ColaDrinksAmountlbl.TabIndex = 3;
            this.ColaDrinksAmountlbl.Text = "20";
            this.ColaDrinksAmountlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ColaDrinksLeftlbl
            // 
            this.ColaDrinksLeftlbl.AutoSize = true;
            this.ColaDrinksLeftlbl.Location = new System.Drawing.Point(102, 28);
            this.ColaDrinksLeftlbl.Name = "ColaDrinksLeftlbl";
            this.ColaDrinksLeftlbl.Size = new System.Drawing.Size(61, 13);
            this.ColaDrinksLeftlbl.TabIndex = 2;
            this.ColaDrinksLeftlbl.Text = "Drinks Left:";
            // 
            // ColaCostlbl
            // 
            this.ColaCostlbl.AutoSize = true;
            this.ColaCostlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColaCostlbl.Location = new System.Drawing.Point(109, 6);
            this.ColaCostlbl.Name = "ColaCostlbl";
            this.ColaCostlbl.Size = new System.Drawing.Size(39, 13);
            this.ColaCostlbl.TabIndex = 1;
            this.ColaCostlbl.Text = "$1.00";
            // 
            // Colapbx
            // 
            this.Colapbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Colapbx.Image = ((System.Drawing.Image)(resources.GetObject("Colapbx.Image")));
            this.Colapbx.Location = new System.Drawing.Point(3, 3);
            this.Colapbx.Name = "Colapbx";
            this.Colapbx.Size = new System.Drawing.Size(79, 79);
            this.Colapbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Colapbx.TabIndex = 0;
            this.Colapbx.TabStop = false;
            this.Colapbx.Click += new System.EventHandler(this.Colapbx_Click);
            // 
            // RootBeerpnl
            // 
            this.RootBeerpnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.RootBeerpnl.Controls.Add(this.RootBeerDrinksAmountlbl);
            this.RootBeerpnl.Controls.Add(this.RootBeerDrinksLeftlbl);
            this.RootBeerpnl.Controls.Add(this.RootBeerCostlbl);
            this.RootBeerpnl.Controls.Add(this.RootBeerpbx);
            this.RootBeerpnl.Cursor = System.Windows.Forms.Cursors.No;
            this.RootBeerpnl.Location = new System.Drawing.Point(194, 49);
            this.RootBeerpnl.Name = "RootBeerpnl";
            this.RootBeerpnl.Size = new System.Drawing.Size(176, 89);
            this.RootBeerpnl.TabIndex = 2;
            // 
            // RootBeerDrinksAmountlbl
            // 
            this.RootBeerDrinksAmountlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RootBeerDrinksAmountlbl.Location = new System.Drawing.Point(99, 47);
            this.RootBeerDrinksAmountlbl.Name = "RootBeerDrinksAmountlbl";
            this.RootBeerDrinksAmountlbl.Size = new System.Drawing.Size(68, 29);
            this.RootBeerDrinksAmountlbl.TabIndex = 3;
            this.RootBeerDrinksAmountlbl.Text = "20";
            this.RootBeerDrinksAmountlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RootBeerDrinksLeftlbl
            // 
            this.RootBeerDrinksLeftlbl.AutoSize = true;
            this.RootBeerDrinksLeftlbl.Location = new System.Drawing.Point(102, 28);
            this.RootBeerDrinksLeftlbl.Name = "RootBeerDrinksLeftlbl";
            this.RootBeerDrinksLeftlbl.Size = new System.Drawing.Size(61, 13);
            this.RootBeerDrinksLeftlbl.TabIndex = 2;
            this.RootBeerDrinksLeftlbl.Text = "Drinks Left:";
            // 
            // RootBeerCostlbl
            // 
            this.RootBeerCostlbl.AutoSize = true;
            this.RootBeerCostlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RootBeerCostlbl.Location = new System.Drawing.Point(109, 6);
            this.RootBeerCostlbl.Name = "RootBeerCostlbl";
            this.RootBeerCostlbl.Size = new System.Drawing.Size(39, 13);
            this.RootBeerCostlbl.TabIndex = 1;
            this.RootBeerCostlbl.Text = "$1.00";
            // 
            // RootBeerpbx
            // 
            this.RootBeerpbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RootBeerpbx.Image = ((System.Drawing.Image)(resources.GetObject("RootBeerpbx.Image")));
            this.RootBeerpbx.Location = new System.Drawing.Point(3, 3);
            this.RootBeerpbx.Name = "RootBeerpbx";
            this.RootBeerpbx.Size = new System.Drawing.Size(79, 79);
            this.RootBeerpbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.RootBeerpbx.TabIndex = 0;
            this.RootBeerpbx.TabStop = false;
            this.RootBeerpbx.Click += new System.EventHandler(this.RootBeerpbx_Click);
            // 
            // LemonLimepnl
            // 
            this.LemonLimepnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LemonLimepnl.Controls.Add(this.LemonLimeDrinksAmountlbl);
            this.LemonLimepnl.Controls.Add(this.LemonLimeLeftlbl);
            this.LemonLimepnl.Controls.Add(this.LemonLimeCostlbl);
            this.LemonLimepnl.Controls.Add(this.LemonLimepxb);
            this.LemonLimepnl.Cursor = System.Windows.Forms.Cursors.No;
            this.LemonLimepnl.Location = new System.Drawing.Point(12, 144);
            this.LemonLimepnl.Name = "LemonLimepnl";
            this.LemonLimepnl.Size = new System.Drawing.Size(176, 89);
            this.LemonLimepnl.TabIndex = 6;
            // 
            // LemonLimeDrinksAmountlbl
            // 
            this.LemonLimeDrinksAmountlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LemonLimeDrinksAmountlbl.Location = new System.Drawing.Point(99, 47);
            this.LemonLimeDrinksAmountlbl.Name = "LemonLimeDrinksAmountlbl";
            this.LemonLimeDrinksAmountlbl.Size = new System.Drawing.Size(68, 29);
            this.LemonLimeDrinksAmountlbl.TabIndex = 3;
            this.LemonLimeDrinksAmountlbl.Text = "20";
            this.LemonLimeDrinksAmountlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LemonLimeLeftlbl
            // 
            this.LemonLimeLeftlbl.AutoSize = true;
            this.LemonLimeLeftlbl.Location = new System.Drawing.Point(102, 28);
            this.LemonLimeLeftlbl.Name = "LemonLimeLeftlbl";
            this.LemonLimeLeftlbl.Size = new System.Drawing.Size(61, 13);
            this.LemonLimeLeftlbl.TabIndex = 2;
            this.LemonLimeLeftlbl.Text = "Drinks Left:";
            // 
            // LemonLimeCostlbl
            // 
            this.LemonLimeCostlbl.AutoSize = true;
            this.LemonLimeCostlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LemonLimeCostlbl.Location = new System.Drawing.Point(109, 6);
            this.LemonLimeCostlbl.Name = "LemonLimeCostlbl";
            this.LemonLimeCostlbl.Size = new System.Drawing.Size(39, 13);
            this.LemonLimeCostlbl.TabIndex = 1;
            this.LemonLimeCostlbl.Text = "$1.00";
            // 
            // LemonLimepxb
            // 
            this.LemonLimepxb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LemonLimepxb.Image = ((System.Drawing.Image)(resources.GetObject("LemonLimepxb.Image")));
            this.LemonLimepxb.Location = new System.Drawing.Point(3, 3);
            this.LemonLimepxb.Name = "LemonLimepxb";
            this.LemonLimepxb.Size = new System.Drawing.Size(79, 79);
            this.LemonLimepxb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LemonLimepxb.TabIndex = 0;
            this.LemonLimepxb.TabStop = false;
            this.LemonLimepxb.Click += new System.EventHandler(this.LemonLimepxb_Click);
            // 
            // GrapeSodapnl
            // 
            this.GrapeSodapnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GrapeSodapnl.Controls.Add(this.GrapeSodaDrinksAmountlbl);
            this.GrapeSodapnl.Controls.Add(this.GrapeSodaDrinksLeftlbl);
            this.GrapeSodapnl.Controls.Add(this.GrapeSodaCostlbl);
            this.GrapeSodapnl.Controls.Add(this.GrapeSodapxb);
            this.GrapeSodapnl.Cursor = System.Windows.Forms.Cursors.No;
            this.GrapeSodapnl.Location = new System.Drawing.Point(194, 144);
            this.GrapeSodapnl.Name = "GrapeSodapnl";
            this.GrapeSodapnl.Size = new System.Drawing.Size(176, 89);
            this.GrapeSodapnl.TabIndex = 7;
            // 
            // GrapeSodaDrinksAmountlbl
            // 
            this.GrapeSodaDrinksAmountlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GrapeSodaDrinksAmountlbl.Location = new System.Drawing.Point(99, 47);
            this.GrapeSodaDrinksAmountlbl.Name = "GrapeSodaDrinksAmountlbl";
            this.GrapeSodaDrinksAmountlbl.Size = new System.Drawing.Size(68, 29);
            this.GrapeSodaDrinksAmountlbl.TabIndex = 3;
            this.GrapeSodaDrinksAmountlbl.Text = "20";
            this.GrapeSodaDrinksAmountlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GrapeSodaDrinksLeftlbl
            // 
            this.GrapeSodaDrinksLeftlbl.AutoSize = true;
            this.GrapeSodaDrinksLeftlbl.Location = new System.Drawing.Point(102, 28);
            this.GrapeSodaDrinksLeftlbl.Name = "GrapeSodaDrinksLeftlbl";
            this.GrapeSodaDrinksLeftlbl.Size = new System.Drawing.Size(61, 13);
            this.GrapeSodaDrinksLeftlbl.TabIndex = 2;
            this.GrapeSodaDrinksLeftlbl.Text = "Drinks Left:";
            // 
            // GrapeSodaCostlbl
            // 
            this.GrapeSodaCostlbl.AutoSize = true;
            this.GrapeSodaCostlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrapeSodaCostlbl.Location = new System.Drawing.Point(109, 6);
            this.GrapeSodaCostlbl.Name = "GrapeSodaCostlbl";
            this.GrapeSodaCostlbl.Size = new System.Drawing.Size(39, 13);
            this.GrapeSodaCostlbl.TabIndex = 1;
            this.GrapeSodaCostlbl.Text = "$1.50";
            // 
            // GrapeSodapxb
            // 
            this.GrapeSodapxb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GrapeSodapxb.Image = ((System.Drawing.Image)(resources.GetObject("GrapeSodapxb.Image")));
            this.GrapeSodapxb.Location = new System.Drawing.Point(3, 3);
            this.GrapeSodapxb.Name = "GrapeSodapxb";
            this.GrapeSodapxb.Size = new System.Drawing.Size(79, 79);
            this.GrapeSodapxb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GrapeSodapxb.TabIndex = 0;
            this.GrapeSodapxb.TabStop = false;
            this.GrapeSodapxb.Click += new System.EventHandler(this.GrapeSodapxb_Click);
            // 
            // CreamSodapnl
            // 
            this.CreamSodapnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CreamSodapnl.Controls.Add(this.CreamSodaDrinksAmountlbl);
            this.CreamSodapnl.Controls.Add(this.CreamSodaDrinksLeftlbl);
            this.CreamSodapnl.Controls.Add(this.CreamSodaCostlbl);
            this.CreamSodapnl.Controls.Add(this.CreamSodapxb);
            this.CreamSodapnl.Cursor = System.Windows.Forms.Cursors.No;
            this.CreamSodapnl.Location = new System.Drawing.Point(12, 239);
            this.CreamSodapnl.Name = "CreamSodapnl";
            this.CreamSodapnl.Size = new System.Drawing.Size(176, 89);
            this.CreamSodapnl.TabIndex = 8;
            // 
            // CreamSodaDrinksAmountlbl
            // 
            this.CreamSodaDrinksAmountlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CreamSodaDrinksAmountlbl.Location = new System.Drawing.Point(99, 47);
            this.CreamSodaDrinksAmountlbl.Name = "CreamSodaDrinksAmountlbl";
            this.CreamSodaDrinksAmountlbl.Size = new System.Drawing.Size(68, 29);
            this.CreamSodaDrinksAmountlbl.TabIndex = 3;
            this.CreamSodaDrinksAmountlbl.Text = "20";
            this.CreamSodaDrinksAmountlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CreamSodaDrinksLeftlbl
            // 
            this.CreamSodaDrinksLeftlbl.AutoSize = true;
            this.CreamSodaDrinksLeftlbl.Location = new System.Drawing.Point(102, 28);
            this.CreamSodaDrinksLeftlbl.Name = "CreamSodaDrinksLeftlbl";
            this.CreamSodaDrinksLeftlbl.Size = new System.Drawing.Size(61, 13);
            this.CreamSodaDrinksLeftlbl.TabIndex = 2;
            this.CreamSodaDrinksLeftlbl.Text = "Drinks Left:";
            // 
            // CreamSodaCostlbl
            // 
            this.CreamSodaCostlbl.AutoSize = true;
            this.CreamSodaCostlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreamSodaCostlbl.Location = new System.Drawing.Point(109, 6);
            this.CreamSodaCostlbl.Name = "CreamSodaCostlbl";
            this.CreamSodaCostlbl.Size = new System.Drawing.Size(39, 13);
            this.CreamSodaCostlbl.TabIndex = 1;
            this.CreamSodaCostlbl.Text = "$1.50";
            // 
            // CreamSodapxb
            // 
            this.CreamSodapxb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CreamSodapxb.Image = ((System.Drawing.Image)(resources.GetObject("CreamSodapxb.Image")));
            this.CreamSodapxb.Location = new System.Drawing.Point(3, 3);
            this.CreamSodapxb.Name = "CreamSodapxb";
            this.CreamSodapxb.Size = new System.Drawing.Size(79, 79);
            this.CreamSodapxb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CreamSodapxb.TabIndex = 0;
            this.CreamSodapxb.TabStop = false;
            this.CreamSodapxb.Click += new System.EventHandler(this.CreamSodapxb_Click);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.TotalSalesOutputlbl);
            this.panel5.Controls.Add(this.TotalSaleslbl);
            this.panel5.Cursor = System.Windows.Forms.Cursors.No;
            this.panel5.Location = new System.Drawing.Point(194, 239);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(176, 89);
            this.panel5.TabIndex = 9;
            // 
            // TotalSalesOutputlbl
            // 
            this.TotalSalesOutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalSalesOutputlbl.Location = new System.Drawing.Point(55, 47);
            this.TotalSalesOutputlbl.Name = "TotalSalesOutputlbl";
            this.TotalSalesOutputlbl.Size = new System.Drawing.Size(68, 29);
            this.TotalSalesOutputlbl.TabIndex = 3;
            this.TotalSalesOutputlbl.Text = "$0.00";
            this.TotalSalesOutputlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalSaleslbl
            // 
            this.TotalSaleslbl.AutoSize = true;
            this.TotalSaleslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalSaleslbl.Location = new System.Drawing.Point(52, 17);
            this.TotalSaleslbl.Name = "TotalSaleslbl";
            this.TotalSaleslbl.Size = new System.Drawing.Size(71, 13);
            this.TotalSaleslbl.TabIndex = 1;
            this.TotalSaleslbl.Text = "Total Sales";
            // 
            // Exitbtn
            // 
            this.Exitbtn.Location = new System.Drawing.Point(155, 334);
            this.Exitbtn.Name = "";
            this.Exitbtn.Size = new System.Drawing.Size(75, 23);
            this.Exitbtn.TabIndex = 10;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 360);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.CreamSodapnl);
            this.Controls.Add(this.GrapeSodapnl);
            this.Controls.Add(this.LemonLimepnl);
            this.Controls.Add(this.RootBeerpnl);
            this.Controls.Add(this.Colapnl);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Colapnl.ResumeLayout(false);
            this.Colapnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Colapbx)).EndInit();
            this.RootBeerpnl.ResumeLayout(false);
            this.RootBeerpnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RootBeerpbx)).EndInit();
            this.LemonLimepnl.ResumeLayout(false);
            this.LemonLimepnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LemonLimepxb)).EndInit();
            this.GrapeSodapnl.ResumeLayout(false);
            this.GrapeSodapnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrapeSodapxb)).EndInit();
            this.CreamSodapnl.ResumeLayout(false);
            this.CreamSodapnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreamSodapxb)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Colapnl;
        private System.Windows.Forms.Label ColaDrinksLeftlbl;
        private System.Windows.Forms.Label ColaCostlbl;
        private System.Windows.Forms.PictureBox Colapbx;
        private System.Windows.Forms.Label ColaDrinksAmountlbl;
        private System.Windows.Forms.Panel RootBeerpnl;
        private System.Windows.Forms.Label RootBeerDrinksAmountlbl;
        private System.Windows.Forms.Label RootBeerDrinksLeftlbl;
        private System.Windows.Forms.Label RootBeerCostlbl;
        private System.Windows.Forms.PictureBox RootBeerpbx;
        private System.Windows.Forms.Panel LemonLimepnl;
        private System.Windows.Forms.Label LemonLimeDrinksAmountlbl;
        private System.Windows.Forms.Label LemonLimeLeftlbl;
        private System.Windows.Forms.Label LemonLimeCostlbl;
        private System.Windows.Forms.PictureBox LemonLimepxb;
        private System.Windows.Forms.Panel GrapeSodapnl;
        private System.Windows.Forms.Label GrapeSodaDrinksAmountlbl;
        private System.Windows.Forms.Label GrapeSodaDrinksLeftlbl;
        private System.Windows.Forms.Label GrapeSodaCostlbl;
        private System.Windows.Forms.PictureBox GrapeSodapxb;
        private System.Windows.Forms.Panel CreamSodapnl;
        private System.Windows.Forms.Label CreamSodaDrinksAmountlbl;
        private System.Windows.Forms.Label CreamSodaDrinksLeftlbl;
        private System.Windows.Forms.Label CreamSodaCostlbl;
        private System.Windows.Forms.PictureBox CreamSodapxb;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label TotalSalesOutputlbl;
        private System.Windows.Forms.Label TotalSaleslbl;
        private System.Windows.Forms.Button Exitbtn;
    }
}


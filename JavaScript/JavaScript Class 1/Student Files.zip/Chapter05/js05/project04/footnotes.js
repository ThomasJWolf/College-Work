"use strict";
/*    JavaScript 7th Edition
      Chapter 5
      Project 05-04

      Project to display footnotes in a popup window
      Author: 
      Date:   

      Filename: footnotes.js
*/

let footnotes = [
   "A serf, a person without freedom", 
   "Unnatural, twisted", "Artfullness", 
   "Lost all color", 
   "Appearance, visage", 
   "The wife of King Priam of Troy during the Trojan War",
   "Anything that prompts a speech or action", 
   "An unclear motivation or intent", 
   "An intent which is not delivered or ready for delivery",
   "Head", 
   "A lie that is deep and pervasive", 
   "An oath, short for by God's Wounds", 
   "A temperment that causes one to be quick to anger", 
   "Before", 
   "Fatted all the birds of the air",
   "Entrails", 
   "Devoid of natural feeling or sympathy", 
   "Curse about my condition", 
   "A loose or immoral woman",
   "A kitchen maid, who does the lowliest work", 
   "Change my thoughts!", 
   "A realistic rendition of a scene",
   "Probe his actions to learn his thoughts", 
   "Flinch", 
   "Deludes me to my damnation", 
   "Relevant"
];